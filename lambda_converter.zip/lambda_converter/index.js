const express = require('express')
const bodyParser = require('body-parser');
const { convertToNodeLambda } = require('./src/handlers/nodeLambdaHandler');
const { convertToDotNetLambda } = require('./src/handlers/dotnetLambdaHandler');
const app = express()
app.use(bodyParser.json());
const port = 3000

app.get('/', (req, res) => {
  res.send('ping successfull')
})

app.post('/convert', function(req, res) {
    console.log('receiving data ...');
    console.log('body is ',req.body);
    switch (req.body.frameworkType) {
      case 'node':
        convertToNodeLambda(req.body);
        break;
      case 'dotnet':
        convertToDotNetLambda(req.body);
        break;
      default:
        break;
    }   
    res.send('Node lambda created successfully');
});

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})