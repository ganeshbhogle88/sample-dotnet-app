const { deleteLocalDirectory } = require("../utils/deleteLocalDirectory");
const { createGitBranch } = require("../utils/gitConnector/gitBranch");
const { commitAndPush } = require("../utils/gitConnector/gitCommitAndPush");
const { cloneGitRepo } = require("../utils/gitConnector/gitclone");
const { createLambda } = require("../utils/nodeConverter/createLambda");
const { createServerlessYaml } = require("../utils/nodeConverter/createServerlessYaml");
const { updatePackageJson } = require("../utils/nodeConverter/updatepackages")

const convertToNodeLambda = async request =>{
  await cloneGitRepo(request.appName,request.gitRepoUrl, request.baseBranch);
  await createGitBranch(request.appName)
  updatePackageJson(request.appName);
  createLambda(request.entryModule,request.appName);
  createServerlessYaml(request.appName);
  await commitAndPush(request.appName)
  deleteLocalDirectory(`./${request.appName}`)
}

module.exports = {
  convertToNodeLambda
}