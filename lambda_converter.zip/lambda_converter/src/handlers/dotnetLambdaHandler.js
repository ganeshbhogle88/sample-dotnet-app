const { deleteLocalDirectory } = require("../utils/deleteLocalDirectory");
const { addAwsDependencies } = require("../utils/dotnetConverter/addAwsDependency");
const { updateProgramFile } = require("../utils/dotnetConverter/updateProgramFile");
const { createGitBranch } = require("../utils/gitConnector/gitBranch");
const { commitAndPush } = require("../utils/gitConnector/gitCommitAndPush");
const { cloneGitRepo } = require("../utils/gitConnector/gitclone");

const convertToDotNetLambda = async request =>{
  await cloneGitRepo(request.appName,request.gitRepoUrl, request.baseBranch);
  await createGitBranch(request.appName)
  await addAwsDependencies(request.appName)
  await updateProgramFile(request.appName);
  await commitAndPush(request.appName)
  deleteLocalDirectory(`./${request.appName}`)
}

module.exports = {
    convertToDotNetLambda
}