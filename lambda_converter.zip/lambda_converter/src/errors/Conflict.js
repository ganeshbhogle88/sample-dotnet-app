class Conflict extends Error {
    constructor(message) {
      super(message);
      this.status = 409;
      this.title = 'AlreadyExist';
      this.detail = 'AlreadyExist: resource alreadry exists !!';
    }
  }
  
  module.exports = Conflict;