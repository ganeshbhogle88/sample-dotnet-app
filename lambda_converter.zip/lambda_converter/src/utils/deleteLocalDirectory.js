const fs = require("fs");
const path = require("path");

const deleteLocalDirectory = dir => {
    const list = fs.readdirSync(dir);
    for(let i = 0; i < list.length; i++) {
        const filename = path.join(dir, list[i]);
        const stat = fs.statSync(filename);

        if(filename == "." || filename == "..") {
            // pass these files
        } else if(stat.isDirectory()) {
            // rmdir recursively
            deleteLocalDirectory(filename);
        } else {
            // rm fiilename
            fs.unlinkSync(filename);
        }
    }

    fs.rmdirSync(dir);
    console.log(`local directory ${dir} deleted successfully !!`)
}

module.exports = {
    deleteLocalDirectory 
}


