const fs = require("fs");

const updateProgramFile = async(appName) => {
    const data = fs.readFileSync(`./${appName}/Program.cs`).toString().split("\n");
    const buildVar = data.find(element => element.includes(".AddControllers()"));
    const index = data.indexOf(buildVar);

    data.splice(index + 1, 0, "builder.Services.AddAWSLambdaHosting(LambdaEventSource.HttpApi);");
    var text = data.join("\n");
    fs.writeFile(`./${appName}/Program.cs`, text, function (err) {
    if (err) return console.log(err);
    });
}

module.exports = {
 updateProgramFile
}