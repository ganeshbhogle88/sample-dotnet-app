const fs = require("fs");
const yaml = require('js-yaml');

const createServerlessYaml = (appName) =>{
    const serverlessFile = yaml.load(fs.readFileSync('./src/utils/nodeConverter/templates/serverless.yml', 'utf8'));
    fs.writeFile(`./${appName}/serverless.yml`, yaml.dump(serverlessFile), (err) => {
        if (err) {
            console.log(err);
        }
    });
}

module.exports = {
    createServerlessYaml
}