const fs = require("fs");

const updateStartFile = (appName,entryModule) =>{
    const fileData = fs.readFileSync(`./${appName}/${entryModule}.js`, "utf8")
    // Use JSON.parse to convert string to JSON Object
    const updatedFile = fileData.replace(".*\.listen.*\(.*\).*\{(?:.|\n)*?\n\}\)", "");
    fs.writeFileSync(`./${appName}/${entryModule}.js`, updatedFile)
}

module.exports = {
    updateStartFile
}