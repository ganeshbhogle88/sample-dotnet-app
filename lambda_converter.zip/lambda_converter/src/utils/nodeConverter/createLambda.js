const fs = require("fs");

const createLambda = (entryModule,appName) =>{
    const lambdaJsTemplate = `const awsServerlessExpress = require('aws-serverless-express')
    const app = require('./${entryModule}')
    const server = awsServerlessExpress.createServer(app)    
    exports.handler = (event, context) => { awsServerlessExpress.proxy(server, event, context) }`;

    fs.writeFile(`./${appName}/lambda.js`, lambdaJsTemplate, function (err) {
        if (err) throw err;
        console.log('Lambda File is created successfully.');        
    });
}

module.exports = {
    createLambda
}