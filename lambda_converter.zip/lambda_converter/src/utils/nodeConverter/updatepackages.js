const fs = require("fs");

const updatePackageJson = appName =>{
    const fileData = fs.readFileSync(`./${appName}/package.json`, "utf8")
    // Use JSON.parse to convert string to JSON Object
    const jsonData = JSON.parse(fileData)
    const dependencies = jsonData["dependencies"];
    dependencies["aws-serverless-express"] = "^3.4.0"
    jsonData["dependencies"] = dependencies;

    const devDependencies = jsonData["devDependencies"];
    devDependencies["serverless-offline"] = "^11.0.0"
    jsonData["devDependencies"] = devDependencies;   

    const scripts = jsonData["scripts"];
    scripts["lambda-start"] = "serverless offline start"
    jsonData["scripts"] = scripts; 

    fs.writeFileSync(`./${appName}/package.json`, JSON.stringify(jsonData, null, "\t"))
}

module.exports = {
    updatePackageJson
}