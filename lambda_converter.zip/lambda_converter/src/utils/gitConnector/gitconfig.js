const { simpleGit } = require("simple-git")

const configGit = (gitPath) => {
    const options = {
        baseDir: gitPath,
        binary: 'git',
        maxConcurrentProcesses: 6,
        trimmed: false,
     };
     return simpleGit(options); 
 }

module.exports = configGit;