const configGit = require('./gitconfig');

const createGitBranch = async (appName) => {
    const git = configGit(`./${appName}`);
    await git.checkoutLocalBranch(`release-${appName}_lambda`);
}

module.exports = {
    createGitBranch
};
