
const fs = require('fs')
const configGit = require('./gitconfig');
const Conflict = require('../../errors/Conflict');

const cloneGitRepo = async (appName, gitRepoUrl, baseBranch) => {
    const git = configGit(process.cwd());    
    const localPath = `./${appName}`;
    const callback = () => {
    console.log('completed git clone !!') 
    }

    if (fs.existsSync(localPath)) {
       throw new Conflict("Repository already exist on local");
    } else {
      await git.clone(gitRepoUrl, localPath, {"--branch": baseBranch}, callback);
    }    
}

module.exports = {
    cloneGitRepo
};






