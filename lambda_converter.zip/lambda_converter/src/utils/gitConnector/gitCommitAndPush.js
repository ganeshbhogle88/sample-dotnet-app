const configGit = require('./gitconfig');

const commitAndPush = async appName =>{
    const git = configGit(`./${appName}`);
    await git.add('./*')
   .commit('first lambda commit!')
   .push(['-u', 'origin', `release-${appName}_lambda`], () => console.log('Branch pushed successfully !!'));
}

module.exports = {
    commitAndPush
};